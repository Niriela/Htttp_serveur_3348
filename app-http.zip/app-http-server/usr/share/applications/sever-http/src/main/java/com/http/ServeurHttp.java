package com.http;

import java.io.*;
import java.net.*;

public class ServeurHttp {
    private ServerSocket serverSocket = null;
    private final int port;

    public int getPort() {
        return port;
    }

    public ServeurHttp(int port) {
        this.port = port;
    }

    // FUNCTIONS
    // demarre le service socket
    public void startServer() {
        try {
            this.serverSocket = new ServerSocket(this.getPort(), 100, InetAddress.getByName("0.0.0.0"));
            Config.logToFile("[START] Server started on port : " + port);
            System.out.println("HTTP Server started on port " + port);

            while (!serverSocket.isClosed()) { // Vérifier si le serveur est toujours actif
                Socket clientSocket = serverSocket.accept();
                HandleRequest.handleRequest(clientSocket);
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    public void stopServer() {
        try {
            if (serverSocket != null) {
                serverSocket.close(); // Ferme la socket
                Config.logToFile("[STOP] Server started on port : " + port);
            }
            // threadPool.shutdown(); // Arrête le pool de threads
            System.out.println("Server stopped.");
        } catch (IOException e) {
            System.err.println("Error stopping server: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

}
