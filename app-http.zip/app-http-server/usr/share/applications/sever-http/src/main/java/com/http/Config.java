package com.http;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

public class Config {

    private static int port;
    private static String path;
    private static boolean php_enable;
    private static final String CONFIG_FILE = "src/main/resources/config/config.txt";
    private static final String LOG_FILE = "src/main/resources/config/log.txt";

    public static int getPort() {
        return port;
    }

    public static String getPath() {
        return path;
    }

    public static void setPort(int newPort) {
        if (isValidPort(newPort)) {
            port = newPort;
            saveConfig();
            logToFile("[PORT CHANGED] Server port has changed to : " + newPort);
        } else {
            logToFile("[ERROR] Invalid port : " + newPort + " attempted at " + "[" + getCurrentDateTime() + "]");
        }
    }

    public static void setPath(String newPath) {
        path = newPath;
        saveConfig();
        logToFile("[PATH CHANGED] Server path has changed to : " + newPath);
    }

    public static boolean isPhpEnabled() {
        return php_enable;
    }

    public static void setPhpEnabled(boolean newPhpEnable) {
        php_enable = newPhpEnable;
        saveConfig();
        logToFile("[PHP STATUS] PHP support has been " + (newPhpEnable ? "enable" : "disable"));
    }

    public static void loadConfig() {
        try (FileInputStream input = new FileInputStream(CONFIG_FILE)) {
            Properties properties = new Properties();
            properties.load(input);
            port = Integer.parseInt(properties.getProperty("port", "1148"));
            path = properties.getProperty("path", "src/main/resources/htdocs");
            php_enable = Boolean.parseBoolean(properties.getProperty("php_enable", String.valueOf(true)));
        } catch (IOException | NumberFormatException e) {
            logToFile("[ERROR] Failed to load config - " + e.getMessage() + " at " + "[" + getCurrentDateTime() + "]");
            port = 1148;
            path = "src/main/resources/htdocs";
            php_enable = true;
        }
    }

    public static void logToFile(String message) {
        try (PrintWriter writer = new PrintWriter(new FileOutputStream(LOG_FILE, true))) {
            writer.println("[" + getCurrentDateTime() + "]" + message);
        } catch (IOException e) {
            throw new RuntimeException();
        }
    }

    public static boolean isValidPort(int port) {
        return port >= 1024 && port <= 65535;
    }

    private static void saveConfig() {
        try (FileOutputStream output = new FileOutputStream(CONFIG_FILE)) {
            Properties properties = new Properties();
            properties.setProperty("php_enable", String.valueOf(php_enable));
            properties.setProperty("port", String.valueOf(port));
            properties.setProperty("path", path);
            properties.store(output, "Server Configuration");
        } catch (IOException e) {
            logToFile("[ERROR] Failed to save config - " + e.getMessage() + " at " + "[" + getCurrentDateTime() + "]");
        }
    }

    private static String getCurrentDateTime() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
}
