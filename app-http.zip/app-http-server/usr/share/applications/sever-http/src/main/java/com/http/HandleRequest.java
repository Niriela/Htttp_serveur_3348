package com.http;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class HandleRequest {

    public static String getPostData(BufferedReader in) 
    {
        String line;
        int contentLength = 0;
        String postData ="";

        try {
            while (!(line = in.readLine()).isEmpty()) {
                // System.out.println("En-tête : " + line);
                if (line.startsWith("Content-Length")) {
                    contentLength = Integer.parseInt(line.split(":")[1].trim());
                }
            }
    
            if (contentLength > 0) {
                char[] buffer = new char[contentLength];
                int readBytes = in.read(buffer, 0, contentLength);
                if (readBytes == contentLength) {
                    postData = new String(buffer);
                    System.out.println("Données POST reçues : " + postData);
                } else {
                    System.out.println("Erreur : Données POST incomplètes.");
                }
                return postData;
            } else {
                System.out.println("Erreur : Pas de contenu POST détecté.");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return postData;
    }

  
    public static String getPathInTheUrl(String requestLine) { ///prendre le fichier avec les parametres get "?": /form.php?name=Nirii
        String[] parts = requestLine.split(" ");
        return parts[1].equals("/") ? "/file_list.html" : parts[1];
    }

    public static String getContentType(File file) {
        String contentType = "text/html"; 
        if (file.getName().endsWith(".jpeg")) {
            contentType = "image/jpeg";
        } else if (file.getName().endsWith(".png") ) {
            contentType = "image/png";
        } else if (file.getName().endsWith(".txt")) {
            contentType = "text/plain";
        }else if (file.getName().endsWith(".php")){
            contentType = "text/html; charset=UTF-8";
        } else if(file.getName().endsWith(".css")) {
            contentType="text/css";
        }
        System.out.println(contentType);
        return contentType;
    }

    ///traitement requete php(interpreteur)
    public static void doRequestFile(OutputStream out, String path, String method, String postData) {
        Config.loadConfig();
        File f;
        //    private static Map<String, String> sessionCookies = new HashMap<>();
        String absolute_path = Config.getPath();

        if(path.contains("?"))
        {
            System.out.println("okkkkkkkkkk");
//            f= new File("src/main/resources/htdocs"+ path.split("\\?")[0]);
            f = new File(absolute_path + path.split("\\?")[0]);
        }
        else{
    //            f= new File("src/main/resources/htdocs"+ path);
            f = new File(absolute_path + path);
        }

        System.out.println("REQUEST FILE: "+ f.getPath());
        try {
            if (!f.exists() || !f.isFile()) {
                System.out.println("neeeinnnnn");

                int statusCode = 404;
                String msg = "Not Found";
                String errorMsg = "404-File not found: " + f.getName();

                out.write(("HTTP/1.1 " + statusCode + " " + msg + "\r\n").getBytes());
                out.write(("Content-Type: text/html\r\n").getBytes());
                out.write(("Content-Length: " + errorMsg.length() + "\r\n").getBytes());
                out.write("\r\n".getBytes());
                out.write(errorMsg.getBytes());
                out.flush();
            }
            else if(getContentType(f).contains("text/html")){
                    ///interpreteur PHP
                    System.out.println("hummm path: " + path);
    
                    ///execution et traitement de la requete.php
                    String phpOutput = PhpExecutor.executePhpScript(path, method, postData);
                    byte[] fileContent = phpOutput.getBytes(StandardCharsets.UTF_8);
    
                    String headers = "HTTP/1.1 " + "200" + " " + "OK" + "\r\n" +
                            "Content-Type: " + getContentType(f) + "\r\n" +
                            "Content-Length: " + fileContent.length + "\r\n" +
                            "\r\n";
    
                    out.write(headers.getBytes(StandardCharsets.UTF_8));
                    out.write(fileContent);
                    out.flush();
                }
                else{
                    byte [] file=Files.readAllBytes(f.toPath());
                    int length=file.length;
                    String headers = "HTTP/1.1 " + "200" + " " + "OK" + "\r\n" +
                            "Content-Type: " + getContentType(f) + "\r\n" +
                            "Content-Length: " + length + "\r\n" +
                            "\r\n";
    
                    out.write(headers.getBytes(StandardCharsets.UTF_8));
                    out.write(file);
                    out.flush();
                }
            
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    ///function final
    public static void handleRequest(Socket clientSocket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter print = new PrintWriter(clientSocket.getOutputStream(), true)) {
            OutputStream out = clientSocket.getOutputStream();

            // Lire la première ligne de la requête
            String requestLine = in.readLine();
            System.out.println("Requête reçue: " + requestLine);

            if (requestLine != null && (requestLine.startsWith("GET") || requestLine.startsWith("POST"))) {
                String filePath = getPathInTheUrl(requestLine);   ///prendre le chemin sans le "?"
                System.out.println("File: " + filePath);
                String method = requestLine.split(" ")[0];

                ///getPost
                String postData="";
                if (requestLine.startsWith("POST")) {
                    postData = getPostData(in);
                    System.out.println("Données POST reçues : " + postData);
                }

                // Traitement du fichier
                try {
                    if(filePath.endsWith(".php")){
                        if(Config.isPhpEnabled()){
                            doRequestFile(out, filePath, method, postData); ///traitement requete php
                        }else{
                            print.println("HTTP/1.1 403 FILE FORBIDDEN");
                            print.println("Content-Type: text/html");
                            print.println();
                            print.println("<h1>403  FILE FORBIDDEN </h1>");
                        }
                    }
                    else{
                        doRequestFile(out, filePath, method, postData);
                    }
                } catch (Exception e) {
                    print.println("HTTP/1.1 500 Internal Server Error");
                    print.println("Content-Type: text/html");
                    print.println();
                    print.println("<h1>500 Internal Server Error</h1>");
                    throw new RuntimeException();
                }
            }
        } catch (IOException e) {
            throw new RuntimeException();
        }
    }
}