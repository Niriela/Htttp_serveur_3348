module com.http {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires java.datatransfer;


    opens com.http to javafx.fxml;
    exports com.http;
}