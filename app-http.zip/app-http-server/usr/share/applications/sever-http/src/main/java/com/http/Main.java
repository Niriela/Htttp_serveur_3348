package com.http;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.stage.DirectoryChooser;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.scene.image.Image;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Objects;
import java.util.Optional;

public class Main extends Application {

    private static final String LOG_FILE = "src/main/resources/config/log.txt";
    private ServeurHttp httpServer;
    private TextFlow logFlow;
    private int port;
    private String path;
    private final Button start_button = new Button("Start Server");
    private final Button stop_button = new Button("Stop Server");
    private final Button open_browser = new Button("Open Browser");
    private final Button config_button = new Button("Config Server");

    @Override
    public void start(Stage stage) {
        stop_button.setDisable(true);
        open_browser.setDisable(true);
        config_button.setDisable(true);

        start_button.getStyleClass().add("green-button");
        stop_button.getStyleClass().add("red-button");
        open_browser.getStyleClass().add("blue-button");
        config_button.getStyleClass().add("config-button");

        logFlow = new TextFlow();
        ScrollPane scrollPane = new ScrollPane(logFlow);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        logFlow.getStyleClass().add("text-flow");

        Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/icons/server.jpg")));
        VBox.setVgrow(scrollPane, Priority.ALWAYS);

        start_button.setOnAction(e -> startServer());
        stop_button.setOnAction(e -> stopServer());
        open_browser.setOnAction(e -> openBrowser());
        config_button.setOnAction(e -> openConfigWindow(stage));

        HBox button_bar = new HBox(10, start_button, stop_button, open_browser, config_button);
        button_bar.setStyle("-fx-padding: 10; -fx-alignment: center;");

        VBox root = new VBox(10, button_bar, scrollPane);
        root.setStyle("-fx-padding: 10;");

        Scene scene = new Scene(root, 500, 400);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/css/style.css")).toExternalForm());

        stage.setTitle("HTTP Server Control Panel");
        stage.getIcons().add(icon);
        stage.setScene(scene);
        stage.show();
    }

    private void startServer() {
        Config.loadConfig();
        port = Config.getPort();

        if (httpServer == null) {
            httpServer = new ServeurHttp(Config.getPort());
            createFileList();
        }

        appendLog("Starting server...", "green-text");
        appendLog("Server started on port : " + port, "green-text");

        new Thread(() -> {
            try {
                httpServer.startServer();
            } catch (RuntimeException e) {
                appendLog("Error starting server: " + e.getMessage(), "red-text");
                throw new RuntimeException();
            }
        }).start();

        start_button.setDisable(true);
        stop_button.setDisable(false);
        open_browser.setDisable(false);
        config_button.setDisable(false);
    }

    private void stopServer() {
        if (httpServer != null) {
            appendLog("Stopping server...", "red-text");
            httpServer.stopServer();
            appendLog("Server Stopped", "red-text");
            httpServer = null;
        }

        start_button.setDisable(false);
        stop_button.setDisable(true);
        open_browser.setDisable(true);
        config_button.setDisable(true);
    }

    private void openBrowser() {
        appendLog("Opening browser...", "blue-text");

        Task<Void> browser_task = new Task<>() {
            @Override
            protected Void call() {
                Config.loadConfig();
                port = Config.getPort();

                try {
                    String url;
                    url = "http://localhost:" + port + "/file_list.html";
                    Desktop.getDesktop().browse(new URI(url));
                    appendLog("Browser opened", "blue-text");
                } catch (IOException | URISyntaxException e) {
                    appendLog("Failed to open browser: " + e.getMessage(), "red-text");
                    throw new RuntimeException(e);
                }

                return null;
            }
        };
        new Thread(browser_task).start();
    }

    private void openConfigWindow(Stage parentStage) {
        path = Config.getPath();
        boolean php_enable = Config.isPhpEnabled();
        Stage configStage = new Stage();
        configStage.setTitle("Server Configuration");

        Label port_label = new Label("Port :");
        TextField portField = new TextField(String.valueOf(port));
        portField.setPromptText("Enter port");

        Label pathLabel = new Label("Root Folder : " + path);
        Button choosePathButton = new Button("Change Root Folder");
        choosePathButton.getStyleClass().add("config-button");

        Button saveButton = new Button("Save");
        saveButton.getStyleClass().add("config-button");

        Label phpLabel = new Label("PHP Support : ");
        CheckBox phpSwitch = new CheckBox();
        phpSwitch.setSelected(php_enable);

        phpSwitch.selectedProperty().addListener((obs, oldValue, newValue) -> Config.setPhpEnabled(newValue));

        HBox phpBox = new HBox(15, phpLabel, phpSwitch);
        phpBox.setAlignment(Pos.CENTER);

        choosePathButton.setOnAction(e -> {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("Select Root Folder");
            File selectedDirectory = directoryChooser.showDialog(configStage);
            if (selectedDirectory != null) {
                path = selectedDirectory.getAbsolutePath();
                Config.setPath(path);
                pathLabel.setText("Root Folder: " + path);
            }
        });

        saveButton.setOnAction(e -> {
            boolean confirmed = showConfirmationDialogue();

            if (confirmed) {
                System.out.println("User make changes");
                try {
                    port = Integer.parseInt(portField.getText());
                    boolean valid_port = Config.isValidPort(port);
                    Config.setPort(port);

                    if (valid_port) {
                        appendLog("Configuration updated.", "gray-text");
                        stopServer();
                        startServer();
                        configStage.close();
                        appendLog("Server restarted.", "gray-text");
                    } else {
                        showAlert("Invalid Port", "Please enter a valid port number between 1024 - 65535");
                    }
                } catch (NumberFormatException ex) {
                    showAlert("Invalid Port", "Please enter a valid port number.");
                }
            } else {
                System.out.println("No changed made");
            }

            configStage.close();
        });

        Button open_log_button = new Button("Open Log");
        open_log_button.getStyleClass().add("config-button");
        open_log_button.setOnAction(e -> openLogFile());

        VBox configLayout = new VBox(10,
                port_label,
                portField,
                phpBox,
                pathLabel,
                choosePathButton,
                open_log_button,
                saveButton
        );
        configLayout.setStyle("-fx-padding: 20;");
        configLayout.setAlignment(Pos.CENTER);
        configLayout.setPadding(new Insets(10));

        Scene configScene = new Scene(configLayout, 400, 300);
        configScene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/css/style.css")).toExternalForm());
        configStage.setScene(configScene);
        configStage.initOwner(parentStage);
        configStage.show();
    }

    private void openLogFile() {
        Task<Void> open_log_file = new Task<>() {
            @Override
            protected Void call() {
                File log_file = new File(LOG_FILE);
                if (log_file.exists()) {
                    try {
                        Desktop.getDesktop().open(log_file);
                    } catch (Exception e) {
                        showAlert("Error", "Unable to open log file.");
                    }
                } else {
                    showAlert("Log Not Found", "The log file does not exist.");
                }

                return null;
            }
        };

        new Thread(open_log_file).start();
    }

    private void appendLog(String message, String styleClass) {
        Platform.runLater(() -> {
            Text text = new Text(message + "\n");
            text.getStyleClass().add(styleClass);
            logFlow.getChildren().add(text);
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean showConfirmationDialogue() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Are you sure to change the configuration ?");
        alert.setContentText("This action can modify the actual parameter");

        ButtonType yes_button = new ButtonType("YES");
        ButtonType no_button = new ButtonType("NO", ButtonType.CANCEL.getButtonData());

        alert.getButtonTypes().setAll(yes_button, no_button);

        Optional<ButtonType> result = alert.showAndWait();

        return result.isPresent() && result.get() == yes_button;
    }

    private void createFileList() {
        path = Config.getPath();
        File htdocsDir = new File(path);

        if (!htdocsDir.exists() || !htdocsDir.isDirectory()) {
            appendLog("Le répertoire est introuvable.", "red-text");
            return;
        }

        StringBuilder fileListPage = new StringBuilder();
        fileListPage.append("<html><body><h1>Liste des fichiers</h1><ul>");
        File[] files = htdocsDir.listFiles();
        if (files != null) {
            for (File file : files) {
                fileListPage.append("<li><a href='http://localhost:")
                        .append(port)
                        .append("/")
                        .append(file.getName())
                        .append("'>")
                        .append(file.getName())
                        .append("</a></li>");
            }
        }
        fileListPage.append("</ul></body></html>");

        File tempFile = new File(htdocsDir, "file_list.html");
        try (PrintWriter writer = new PrintWriter(tempFile)) {
            writer.write(fileListPage.toString());
        } catch (IOException e) {
            appendLog("Error" + e.getMessage(), "red-text");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
