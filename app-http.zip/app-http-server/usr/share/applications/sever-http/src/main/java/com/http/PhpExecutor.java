package com.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Vector;

public class PhpExecutor {

    public static String executePhpScript(String filePath, String method, String postData) throws IOException {
        Config.loadConfig();
        String absolute_path = Config.getPath();
        ProcessBuilder processBuilder;
        StringBuilder output = new StringBuilder();
        Vector<String> commands = new Vector<>();
        commands.add("php");
        commands.add("-r");

        // Vérifie si c'est une requête GET ou POST
        if ("GET".equals(method)) {
            // Séparer le chemin et les paramètres GET (après '?')
            String[] parts = filePath.split("\\?");
            String phpFilePath = parts[0]; // Fichier PHP sans les paramètres
            String params = parts.length > 1 ? parts[1] : ""; // Paramètres GET

            // Création du processus PHP pour une requête GET
            commands.add("parse_str('" + params + "', $_GET); include('" + absolute_path + phpFilePath + "');");
            processBuilder = new ProcessBuilder(commands);
            processBuilder.redirectErrorStream(true);

            // Lancer le processus PHP
            Process process = processBuilder.start();

            // Lire la sortie du processus PHP
            try (BufferedReader phpOutput = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = phpOutput.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }

        } else if ("POST".equals(method)) {
            System.out.println("postDtata: "+ postData);
            // Créer la commande pour exécuter PHP en mode POST
            commands.add("parse_str('" + postData + "', $_POST); include('" + absolute_path + filePath + "');");
            
            processBuilder = new ProcessBuilder(commands);
            processBuilder.redirectErrorStream(true);

            // Lancer le processus PHP
            Process process = processBuilder.start();

            // Écrire les données POST dans l'entrée standard du processus PHP
            try (OutputStream outputStream = process.getOutputStream()) {
                outputStream.write(postData.getBytes());
                outputStream.flush();
            }

            // Lire la sortie du processus PHP
            try (BufferedReader phpOutput = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = phpOutput.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
        } else {
            output.append("Méthode HTTP inconnue.");
        }
        System.out.println(output);
        return output.toString();
    }

}