<?php 

$_SESSION['name'] = "TEST";  
$_SESSION['age'] = "14";  
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire GET et POST</title>
</head>
<body>
    <h1>Test GET et POST</h1>

    <!-- Affichage du message après la soumission -->
    <?php
        if(isset ($_GET['name']))
        {
            echo($_GET['name']);
        }
        if(isset ($_POST['namePost']))
        {
            echo($_POST['namePost']);
        }
        if (isset($_GET['names']) && isset($_GET['age'])) {
            echo $_GET['names'] ;
            echo $_GET['age'] ;
        } else {
            echo "<h2>Aucun paramètre reçu encore !</h2>";
        }
    ?>

    <!-- Formulaire GET -->
    <form action="form.php" method="GET">
        <label for="name">Nom (GET) :</label>
        <input type="text" id="name" name="name" required>
        <button type="submit">Envoyer (GET)</button>
    </form>
    <br>

    <!-- Formulaire POST -->
    <form action="form.php" method="POST">
        <label for="namePost"> Nom (POST) :</label>
        <input type="text" id="namePost" name="namePost" required>
        <button type="submit">Envoyer (POST)</button>
    </form>

</body>
</html>
